// A typical single-user app: everything lives in localStorage.
const KEY = 'team-tasks-v1';
const FILES = 'team-files-v1';
let tasks = JSON.parse(localStorage.getItem(KEY) || '[]');
let files = JSON.parse(localStorage.getItem(FILES) || '[]');
let filter = 'all';

function save() { localStorage.setItem(KEY, JSON.stringify(tasks)); }
function saveFiles() { localStorage.setItem(FILES, JSON.stringify(files)); }

function render() {
  const open = tasks.filter(t => !t.done).length;
  document.getElementById('summary').textContent = `${tasks.length} tasks, ${open} open`;
  const list = document.getElementById('list');
  list.innerHTML = '';
  tasks.filter(t => filter === 'all' || (filter === 'done' ? t.done : !t.done)).forEach(t => {
    const li = document.createElement('li');
    li.className = 'task' + (t.done ? ' done' : '');
    li.dataset.id = t.id;
    li.innerHTML = `<input type="checkbox" ${t.done ? 'checked' : ''} aria-label="Done"><span class="text" contenteditable="true"></span><span class="who"></span><button class="del" aria-label="Delete">Delete</button>`;
    li.querySelector('.text').textContent = t.title;
    li.querySelector('.who').textContent = t.who;
    li.querySelector('input').onchange = e => { t.done = e.target.checked; save(); render(); };
    li.querySelector('.text').onblur = e => { const v = e.target.textContent.trim(); if (v && v !== t.title) { t.title = v; save(); } };
    li.querySelector('.del').onclick = () => { tasks = tasks.filter(x => x.id !== t.id); save(); render(); };
    list.appendChild(li);
  });
  const fl = document.getElementById('filelist');
  fl.innerHTML = '';
  files.forEach(f => {
    const li = document.createElement('li');
    const a = document.createElement('a');
    a.href = f.data; a.download = f.name; a.textContent = `${f.name} (${Math.round(f.size / 1024)} KB)`;
    li.appendChild(a);
    fl.appendChild(li);
  });
}

document.getElementById('add').onsubmit = e => {
  e.preventDefault();
  const title = document.getElementById('title').value.trim();
  if (!title) return;
  tasks.push({ id: crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random(), title, who: document.getElementById('who').value, done: false });
  document.getElementById('title').value = '';
  save(); render();
};
document.getElementById('filters').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  filter = b.dataset.f;
  document.querySelectorAll('#filters button').forEach(x => x.classList.toggle('on', x === b));
  render();
};
document.getElementById('file').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  if (f.size > 2 * 1024 * 1024) { alert('Please pick a file under 2 MB.'); return; }
  const r = new FileReader();
  r.onload = () => { files.push({ id: String(Date.now()), name: f.name, size: f.size, data: r.result }); saveFiles(); render(); };
  r.readAsDataURL(f);
};
render();
